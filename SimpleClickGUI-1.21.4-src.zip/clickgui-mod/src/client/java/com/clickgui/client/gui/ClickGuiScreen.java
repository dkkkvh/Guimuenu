package com.clickgui.client.gui;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

public class ClickGuiScreen extends Screen {

    private final List<Panel> panels = new ArrayList<>();
    private Panel draggingPanel = null;
    private int dragOffsetX, dragOffsetY;

    public ClickGuiScreen() {
        super(Text.literal("ClickGUI"));

        panels.add(new Panel("Combat", 20, 30, 120));
        panels.add(new Panel("Movement", 150, 30, 120));
        panels.add(new Panel("Render", 280, 30, 120));
        panels.add(new Panel("Utility", 410, 30, 120));

        // Demo modules
        panels.get(0).addModule("KillAura", false);
        panels.get(0).addModule("Criticals", true);
        panels.get(0).addModule("AutoClicker", false);
        panels.get(0).addModule("Velocity", true);
        panels.get(0).addModule("Reach", false);

        panels.get(1).addModule("Speed", false);
        panels.get(1).addModule("Fly", false);
        panels.get(1).addModule("Jesus", true);
        panels.get(1).addModule("Step", false);
        panels.get(1).addModule("Sprint", true);

        panels.get(2).addModule("ESP", true);
        panels.get(2).addModule("Tracers", false);
        panels.get(2).addModule("FullBright", true);
        panels.get(2).addModule("NoRender", false);
        panels.get(2).addModule("NameTags", true);

        panels.get(3).addModule("AutoTool", true);
        panels.get(3).addModule("ChestStealer", false);
        panels.get(3).addModule("InvManager", false);
        panels.get(3).addModule("MiddleClick", true);
        panels.get(3).addModule("Timer", false);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        // Dark background
        context.fill(0, 0, this.width, this.height, 0xCC0A0A12);

        // Title
        String title = "ClickGUI  |  Right Shift to close";
        int titleWidth = this.textRenderer.getWidth(title);
        context.drawText(this.textRenderer, title, (this.width - titleWidth) / 2, 8, 0xFF7EC8FF, true);

        for (Panel panel : panels) {
            panel.render(context, mouseX, mouseY, this.textRenderer);
        }

        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0) {
            for (int i = panels.size() - 1; i >= 0; i--) {
                Panel panel = panels.get(i);
                if (panel.isHeaderHovered(mouseX, mouseY)) {
                    draggingPanel = panel;
                    dragOffsetX = (int) (mouseX - panel.x);
                    dragOffsetY = (int) (mouseY - panel.y);
                    panels.remove(panel);
                    panels.add(panel);
                    return true;
                }
                if (panel.mouseClicked(mouseX, mouseY, button)) {
                    return true;
                }
            }
        } else if (button == 1) {
            for (Panel panel : panels) {
                if (panel.isHeaderHovered(mouseX, mouseY)) {
                    panel.expanded = !panel.expanded;
                    return true;
                }
                if (panel.mouseClicked(mouseX, mouseY, button)) {
                    return true;
                }
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        if (button == 0) {
            draggingPanel = null;
        }
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (draggingPanel != null && button == 0) {
            draggingPanel.x = (int) (mouseX - dragOffsetX);
            draggingPanel.y = (int) (mouseY - dragOffsetY);
            return true;
        }
        return super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    public static class Panel {
        public int x, y, width;
        public final String name;
        public boolean expanded = true;
        private final List<ModuleButton> modules = new ArrayList<>();
        private static final int HEADER_HEIGHT = 18;
        private static final int MODULE_HEIGHT = 16;

        public Panel(String name, int x, int y, int width) {
            this.name = name;
            this.x = x;
            this.y = y;
            this.width = width;
        }

        public void addModule(String name, boolean enabled) {
            modules.add(new ModuleButton(name, enabled));
        }

        public void render(DrawContext g, int mouseX, int mouseY, TextRenderer font) {
            int height = HEADER_HEIGHT + (expanded ? modules.size() * MODULE_HEIGHT + 4 : 0);

            // Shadow
            g.fill(x + 3, y + 3, x + width + 3, y + height + 3, 0x40000000);

            // Main bg
            g.fill(x, y, x + width, y + height, 0xE0151525);

            // Border
            int borderColor = 0xFF3A7BD5;
            g.fill(x, y, x + width, y + 1, borderColor);
            g.fill(x, y + height - 1, x + width, y + height, borderColor);
            g.fill(x, y, x + 1, y + height, borderColor);
            g.fill(x + width - 1, y, x + width, y + height, borderColor);

            // Header
            g.fill(x + 1, y + 1, x + width - 1, y + HEADER_HEIGHT, 0xFF1A1A35);
            g.fill(x + 1, y + HEADER_HEIGHT - 1, x + width - 1, y + HEADER_HEIGHT, 0xFF3A7BD5);

            boolean headerHovered = isHeaderHovered(mouseX, mouseY);
            int titleColor = headerHovered ? 0xFF7EC8FF : 0xFFE0E0FF;
            g.drawCenteredTextWithShadow(font, name, x + width / 2, y + 5, titleColor);

            String arrow = expanded ? "v" : ">";
            g.drawText(font, arrow, x + width - 12, y + 5, 0xFFAAAAAA, false);

            if (expanded) {
                int my = y + HEADER_HEIGHT + 2;
                for (ModuleButton mod : modules) {
                    mod.render(g, x + 2, my, width - 4, MODULE_HEIGHT - 1, mouseX, mouseY, font);
                    my += MODULE_HEIGHT;
                }
            }
        }

        public boolean isHeaderHovered(double mx, double my) {
            return mx >= x && mx <= x + width && my >= y && my <= y + HEADER_HEIGHT;
        }

        public boolean mouseClicked(double mx, double my, int button) {
            if (!expanded) return false;

            int myPos = y + HEADER_HEIGHT + 2;
            for (ModuleButton mod : modules) {
                if (mx >= x + 2 && mx <= x + width - 2 && my >= myPos && my <= myPos + MODULE_HEIGHT - 1) {
                    if (button == 0) {
                        mod.enabled = !mod.enabled;
                        return true;
                    }
                }
                myPos += MODULE_HEIGHT;
            }
            return false;
        }
    }

    public static class ModuleButton {
        public final String name;
        public boolean enabled;

        public ModuleButton(String name, boolean enabled) {
            this.name = name;
            this.enabled = enabled;
        }

        public void render(DrawContext g, int x, int y, int w, int h, int mouseX, int mouseY, TextRenderer font) {
            boolean hovered = mouseX >= x && mouseX <= x + w && mouseY >= y && mouseY <= y + h;

            int bg = enabled ? 0xFF1E3A5F : (hovered ? 0xFF252540 : 0xFF1A1A2A);
            g.fill(x, y, x + w, y + h, bg);

            if (enabled) {
                g.fill(x, y, x + 3, y + h, 0xFF3A7BD5);
            }

            int color = enabled ? 0xFF7EC8FF : (hovered ? 0xFFCCCCDD : 0xFF9999AA);
            g.drawText(font, name, x + 8, y + 4, color, false);

            String state = enabled ? "ON" : "OFF";
            int stateColor = enabled ? 0xFF55FF55 : 0xFFFF5555;
            int stateW = font.getWidth(state);
            g.drawText(font, state, x + w - stateW - 6, y + 4, stateColor, false);
        }
    }
}
